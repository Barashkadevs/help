<?php

declare(strict_types=1);


namespace Frago9876543210\PocketEditionClient\protocol;


class StructureBlockUpdatePacket extends DataPacket{
	public const NETWORK_ID = ProtocolInfo::STRUCTURE_BLOCK_UPDATE_PACKET;

	protected function decodePayload() : void{
		//TODO
	}

	protected function encodePayload() : void{
		//TODO
	}
}