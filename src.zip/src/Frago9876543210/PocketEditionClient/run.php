<?php

declare(strict_types=1);

namespace Frago9876543210\PocketEditionClient {

	use Frago9876543210\PocketEditionClient\protocol\PacketPool;
	use pocketmine\entity\Attribute;

	require_once "vendor/autoload.php";
	ini_set("memory_limit", "-1");
	RakNetPool::init();
	PacketPool::init();
	Attribute::init();
	$crash = 'crash.txt';

	echo "[!] Введите IP: ";
	$ip = substr(fgets(STDIN),0,-1);
	var_dump($ip);
	echo "\n[!] Введите PORT: ";
	$port = (int) fgets(STDIN);
	var_dump($port);
	$client = new PocketEditionClient(new Address("0.0.0.0", mt_rand(10000,60000)), new Address($ip, $port));
    $client->sendOpenConnectionRequest1();
	while(true){
		$client->tick();
	}
	
}
